package dto;

public class Product {

}
