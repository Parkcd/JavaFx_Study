package dao;

public class ProductDao {

}
