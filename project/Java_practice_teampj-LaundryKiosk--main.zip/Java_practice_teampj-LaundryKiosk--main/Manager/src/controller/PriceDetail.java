package controller;

public class PriceDetail {

}
